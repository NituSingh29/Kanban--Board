// src/components/Task.js
import React from 'react';
import './Task.css';

function Task({ title }) {
  return <div className="task">{title}</div>;
}

export default Task;
