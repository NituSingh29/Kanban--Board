// src/components/Column.js
import React from 'react';
import './Column.css';
import Task from './Task';

function Column({ title, tasks }) {
  return (
    <div className="column">
      <h3>{title}</h3>
      {tasks.map((task) => (
        <Task key={task.id} title={task.title} />
      ))}
    </div>
  );
}

export default Column;
